Conversión de KMZ a SHP.
Archivo origen: Juan Ilbay.kmz
Cantidad de elementos: 8
Tipo de geometría: MultiPolygon
Nota: los nombres de campos y textos largos fueron adaptados por limitaciones del formato Shapefile.
