Conversión desde KMZ a SHP.
Capa detectada: TuberíadeAguaCHA3
Geometría: líneas (MultiLineString).
Elementos: 1010
Sistema de coordenadas copiado desde el KML/KMZ (usualmente WGS84 / EPSG:4326).
