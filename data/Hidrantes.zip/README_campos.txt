Conversión de KMZ a SHP

Archivo origen: hidCHA3.kmz
Registros: 46
Tipos de geometría: Point

Mapeo de campos (original -> shapefile):
- id -> id
- Name -> Name
- description -> descriptio
- timestamp -> timestamp
- begin -> begin
- end -> end
- altitudeMode -> altitudeMo
- tessellate -> tessellate
- extrude -> extrude
- visibility -> visibility
- drawOrder -> drawOrder
- icon -> icon
- snippet -> snippet
